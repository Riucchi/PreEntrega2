from setuptools import setup

setup(


    name="modulo_1",
    version= "1.0",
    description= "Modulo para la entrega numero 2",
    author= "Lucas Beccarini",
    author_email= "lucasbecca3@hotmail.com",

    packages= ["modulo_1"]

)